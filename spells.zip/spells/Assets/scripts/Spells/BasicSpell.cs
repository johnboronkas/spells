﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class BasicSpell : MonoBehaviour
{
    public float SpellSpeed;

    private Rigidbody2D Rigidbody2D;

    void Start()
    {
        Rigidbody2D = GetComponent<Rigidbody2D>();

        var force = transform.localPosition.normalized * SpellSpeed * Time.deltaTime;
        Rigidbody2D.AddForce(force, ForceMode2D.Impulse);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Collided with " + other.name);
    }
}
