﻿using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class BasicSpell : MonoBehaviour
{
    public float SpellSpeed;

    private Rigidbody2D Rigidbody2D;

    private void Start()
    {
        Rigidbody2D = GetComponent<Rigidbody2D>();

        var force = transform.up * SpellSpeed * Time.deltaTime;
        Rigidbody2D.AddForce(force, ForceMode2D.Impulse);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Collided with " + other.name);
    }
}
