﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    public float PlayerSpeed;
    public float PlayerSprintSpeed;
    public Texture2D CursorTexture;
    
    private Rigidbody2D Rigidbody2D;

    void Start()
    {
        #region Component Assignments
        Rigidbody2D = GetComponent<Rigidbody2D>();
        #endregion

        #region UI Setup
        SetCursor(CursorTexture);
        #endregion
    }

    private void SetCursor(Texture2D cursorTexture)
    {
        var cursorHotSpot = new Vector2(cursorTexture.width / 2, cursorTexture.height / 2);
        Cursor.SetCursor(cursorTexture, cursorHotSpot, CursorMode.Auto);
    }

    private void Update()
    {
        #region Player Rotation
        Vector3 playerPosition = Camera.main.WorldToScreenPoint(transform.position);
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.x -= playerPosition.x;
        mousePosition.y -= playerPosition.y;

        float angle = (Mathf.Atan2(mousePosition.y, mousePosition.x) * Mathf.Rad2Deg) - 90.0f;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
        #endregion
    }

    void FixedUpdate()
    {
        #region Player Movement
        float speed = (Input.GetButton(InputAxes.Sprint) ? PlayerSprintSpeed : PlayerSpeed) * Time.deltaTime;
        float horizonal = Input.GetAxis(InputAxes.Horizontal) * speed;
        float vertical = Input.GetAxis(InputAxes.Vertical) * speed;
        var inputForce = new Vector2(horizonal, vertical);
        Rigidbody2D.AddForce(inputForce);
        #endregion
    }
}
