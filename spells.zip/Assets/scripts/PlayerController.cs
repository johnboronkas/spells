﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    public BasicSpell BasicSpell;
    public Texture2D CursorTexture;

    private float Speed;
    private float SprintSpeed;
    private float ProjectileSpawnDistance;

    private Rigidbody2D Rigidbody2D;

    private void Start()
    {
        Speed = 2000.0f;
        SprintSpeed = 5000.0f;
        ProjectileSpawnDistance = 0.2f;
        
        Rigidbody2D = GetComponent<Rigidbody2D>();
        
        SetCursor(CursorTexture);
    }

    private void SetCursor(Texture2D cursorTexture)
    {
        var cursorHotSpot = new Vector2(cursorTexture.width / 2, cursorTexture.height / 2);
        Cursor.SetCursor(cursorTexture, cursorHotSpot, CursorMode.Auto);
    }

    private void Update()
    {
        HandleRotation();
        HandleSpellCasting();
    }

    private void HandleRotation()
    {
        Vector3 playerPosition = Camera.main.WorldToScreenPoint(transform.position);
        Vector3 mousePosition = Input.mousePosition;
        mousePosition.x -= playerPosition.x;
        mousePosition.y -= playerPosition.y;

        float angle = (Mathf.Atan2(mousePosition.y, mousePosition.x) * Mathf.Rad2Deg) - 90.0f;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }

    private void HandleSpellCasting()
    {
        if (Input.GetButtonDown(InputManager.Spell1))
        {
            CastBasicSpell();
        }
    }

    private void CastBasicSpell()
    {
        var position = transform.position + (ProjectileSpawnDistance * transform.up);
        var rotation = transform.rotation;
        BasicSpell spell = Instantiate(BasicSpell, position, rotation);
    }

    private void FixedUpdate()
    {
        HandleMovement();
    }

    private void HandleMovement()
    {
        float currentSpeed = (Input.GetButton(InputManager.Sprint) ? SprintSpeed : Speed) * Time.deltaTime;
        float horizonal = Input.GetAxis(InputManager.Horizontal) * currentSpeed;
        float vertical = Input.GetAxis(InputManager.Vertical) * currentSpeed;
        var inputForce = new Vector2(horizonal, vertical);
        Rigidbody2D.AddForce(inputForce, ForceMode2D.Force);
    }
}
