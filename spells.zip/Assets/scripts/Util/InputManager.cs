﻿public static class InputManager
{
    public static string Horizontal
    {
        get { return "Horizontal"; }
        private set { }
    }

    public static string Vertical
    {
        get { return "Vertical"; }
        private set { }
    }

    public static string Ability1
    {
        get { return "Ability1"; }
        private set { }
    }

    public static string Sprint
    {
        get { return "Sprint"; }
        private set { }
    }

    public static string Mouse_X
    {
        get { return "Mouse X"; }
        private set { }
    }

    public static string Mouse_Y
    {
        get { return "Mouse Y"; }
        private set { }
    }

    public static string Submit
    {
        get { return "Submit"; }
        private set { }
    }

    public static string Cancel
    {
        get { return "Cancel"; }
        private set { }
    }
}
